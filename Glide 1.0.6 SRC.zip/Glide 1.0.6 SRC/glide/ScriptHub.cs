﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyExploits;
using WeAreDevs_API;

namespace glide
{
    public partial class ScriptHub : Form
    {
        readonly ExploitAPI api = new ExploitAPI();
        EasyExploits.Module mdl = new EasyExploits.Module();
        public ScriptHub()
        {
            InitializeComponent();
        }
        Point lastPoint;

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/zRhwT6HM");
            if (WrdApiRadio2.Checked == true)
            {
                
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {
                
            }
        }

        private void siticoneLabel1_Click(object sender, EventArgs e)
        {

        }

        private void siticonePanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void siticonePanel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void siticonePanel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/es3aYmpm");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/5NARJ6D4");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void WrdApiRadio2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://pastebin.com/raw/zRhwT6HM");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void siticoneButton1_Click_1(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://gitlab.com/L1ZOT/mango-hub/-/raw/main/Mango-Bloxf-Fruits-Beta");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void siticoneButton7_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/main/NewMainScript.lua");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void siticoneButton8_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://rasputin-bf.glitch.me/bloxfruits.lua");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void siticoneButton9_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string Script = wb.DownloadString("https://raw.githubusercontent.com/iK4oS/backdoor.exe/v8/src/main.lua");
            if (WrdApiRadio2.Checked == true)
            {
                api.SendLuaScript(Script);
            }
            else if (EasyExploitsRadio1.Checked == true)
            {
                mdl.ExecuteScript(Script);
            }
            else if (KrnlApiRadio3.Checked == true)
            {

            }
        }

        private void EasyExploitsRadio1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
